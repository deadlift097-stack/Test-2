#include "check.h"
#include "hooks/BedrockBridge.h"

#include <pl/memory/Signature.hpp>

#include <chrono>
#include <string>
#include <thread>
#include <vector>

using namespace betterhitreg;
using Reg = std::uintptr_t;
using Fn6 = Reg (*)(Reg, Reg, Reg, Reg, Reg, Reg);

namespace {

int gAttackCalls = 0;
int gEventCalls = 0;
Reg gLastEventSelf = 0, gLastEventId = 0, gLastEventData = 99;

Reg fakeAttack(Reg, Reg, Reg, Reg, Reg, Reg) {
    ++gAttackCalls;
    return 1;
}
Reg fakeEvent(Reg self, Reg id, Reg data, Reg, Reg, Reg) {
    ++gEventCalls;
    gLastEventSelf = self;
    gLastEventId = id;
    gLastEventData = data;
    return 0;
}

Fn6 hooked(Fn6 target) {
    return reinterpret_cast<Fn6>(pl::memory::stub::detours().at(reinterpret_cast<void*>(target)));
}

void sleepMs(int ms) { std::this_thread::sleep_for(std::chrono::milliseconds(ms)); }

} // namespace

int main() {
    pl::memory::stub::signatures()["ATTACK"] = reinterpret_cast<std::uintptr_t>(&fakeAttack);
    pl::memory::stub::signatures()["EVENT"] = reinterpret_cast<std::uintptr_t>(&fakeEvent);

    std::vector<std::string> logs;
    auto hasLog = [&](const std::string& needle) {
        for (const auto& l : logs) {
            if (l.find(needle) != std::string::npos) return true;
        }
        return false;
    };

    BedrockBridge bridge([&](std::string_view m) { logs.emplace_back(m); });
    ModConfig cfg;

    // 1. Out of the box (no signatures): stays idle and hooks nothing.
    CHECK(!bridge.install(cfg));
    CHECK(!bridge.active());
    CHECK(pl::memory::stub::detours().empty());
    CHECK(hasLog("stays idle"));

    // 2. A signature that does not resolve: stays idle, hooks nothing.
    cfg.hooks.attackSignature = "MISSING";
    cfg.hooks.entityEventSignature = "EVENT";
    CHECK(!bridge.install(cfg));
    CHECK(hasLog("Signature not found"));
    CHECK(pl::memory::stub::detours().empty());

    // 3. Invalid settings are rejected.
    cfg.hooks.attackSignature = "ATTACK";
    cfg.hooks.attackTargetArg = 9;
    CHECK(!bridge.install(cfg));
    cfg.hooks.attackTargetArg = 1;

    // 4. Normal operation.
    cfg.alerts.delays = true;
    cfg.alerts.delayThresholdMs = 20;
    CHECK(bridge.install(cfg));
    CHECK(bridge.active());

    const Fn6 attack = hooked(&fakeAttack);
    const Fn6 event = hooked(&fakeEvent);
    const Reg actor = 0x7f0000001000ULL;

    // The game's own result is passed through, and one predicted flash is issued.
    CHECK(attack(0xA, actor, 0, 0, 0, 0) == 1);
    CHECK(gAttackCalls == 1 && gEventCalls == 1);
    CHECK(gLastEventSelf == actor && gLastEventId == 2 && gLastEventData == 0);

    // A second swing while still waiting does not flash twice.
    attack(0xA, actor, 0, 0, 0, 0);
    CHECK(gAttackCalls == 2 && gEventCalls == 1);

    // The server's matching flash arrives (late) and is swallowed.
    sleepMs(40);
    event(actor, 2, 0, 0, 0, 0);
    CHECK(gEventCalls == 1);
    CHECK(hasLog("Late hit confirmation"));

    // A later server flash with nothing pending passes through to the game.
    event(actor, 2, 0, 0, 0, 0);
    CHECK(gEventCalls == 2);

    // Other entity events are never touched.
    event(actor, 4, 7, 0, 0, 0);
    CHECK(gEventCalls == 3 && gLastEventId == 4 && gLastEventData == 7);

    // A bogus "target" (wrong argument index) is ignored: no flash on garbage.
    const int before = gEventCalls;
    attack(0xA, 0x5, 0, 0, 0, 0);
    CHECK(gEventCalls == before);

    // 5. hurtFlash off: attacks pass through, nothing is predicted.
    cfg.hitreg.hurtFlash = false;
    CHECK(bridge.install(cfg));
    const int e0 = gEventCalls;
    hooked(&fakeAttack)(0xA, actor, 0, 0, 0, 0);
    CHECK(gEventCalls == e0);

    // 6. Ghost detection: prediction never confirmed.
    cfg.hitreg.hurtFlash = true;
    cfg.hitreg.reconcileWindowMs = 50;
    cfg.hitreg.hurtCooldownMs = 0;
    cfg.alerts.ghosts = true;
    CHECK(bridge.install(cfg));
    const Reg other = 0x7f0000002000ULL;
    hooked(&fakeAttack)(0xA, other, 0, 0, 0, 0);
    sleepMs(90);
    hooked(&fakeAttack)(0xA, other, 0, 0, 0, 0);
    CHECK(hasLog("Ghost hit"));

    // 7. Uninstall removes the hooks, reports a summary, and stale detours are harmless.
    const Fn6 staleAttack = hooked(&fakeAttack);
    bridge.uninstall();
    CHECK(!bridge.active());
    CHECK(pl::memory::stub::detours().empty());
    CHECK(hasLog("Session:"));
    CHECK(staleAttack(0xA, actor, 0, 0, 0, 0) == 0);

    std::puts("bridge_test: OK");
    return 0;
}
