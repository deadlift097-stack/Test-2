#pragma once
// Host-side stand-in for the Preloader SDK header. Used ONLY by tests/ on a normal computer.
// The Android build uses the real SDK fetched by CMake.
#include <string_view>

namespace pl::config {

struct FieldSchema {
    std::string_view title{};
    std::string_view description{};
    double minimum = 0;
    double maximum = 0;
    bool readOnly = false;
};

template <class T> struct Schema {};

template <class T> class ConfigFile {
public:
    bool load() { return true; }
    bool save() { return true; }
    T& value() { return mValue; }
    const T& value() const { return mValue; }

private:
    T mValue{};
};

} // namespace pl::config
