#pragma once
// Host-side stand-in for the Preloader SDK header (tests only).
#include <filesystem>
#include <sstream>
#include <string>
#include <string_view>
#include <vector>

namespace ll::mod {

class Logger {
public:
    template <class... A> void info(std::string_view f, A&&... a) { push(f, a...); }
    template <class... A> void warn(std::string_view f, A&&... a) { push(f, a...); }
    template <class... A> void error(std::string_view f, A&&... a) { push(f, a...); }
    template <class... A> void debug(std::string_view f, A&&... a) { push(f, a...); }

    std::vector<std::string> lines;

private:
    template <class... A> void push(std::string_view f, A&&... a) {
        std::string out(f);
        ((replaceFirst(out, a)), ...);
        lines.push_back(out);
    }
    template <class T> static void replaceFirst(std::string& s, const T& v) {
        std::ostringstream os;
        os << v;
        const auto pos = s.find("{}");
        if (pos != std::string::npos) s.replace(pos, 2, os.str());
    }
};

class NativeMod {
public:
    static NativeMod* current() {
        static NativeMod mod;
        return &mod;
    }
    Logger& getLogger() { return mLogger; }
    std::string getName() const { return "BetterHitreg"; }
    std::string getId() const { return "BetterHitreg"; }
    std::filesystem::path getConfigDir() const { return std::filesystem::temp_directory_path() / "betterhitreg_test_cfg"; }

private:
    Logger mLogger;
};

} // namespace ll::mod

#define PL_REGISTER_MOD(Type, instanceExpr) \
    namespace {                             \
    [[maybe_unused]] Type& plRegisteredMod = (instanceExpr); \
    }
