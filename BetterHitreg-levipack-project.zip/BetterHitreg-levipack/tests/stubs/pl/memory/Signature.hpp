#pragma once
// Host-side stand-in for the Preloader SDK header (tests only).
#include <cstdint>
#include <map>
#include <string>
#include <string_view>

namespace pl::memory {

namespace stub {
inline std::map<std::string, std::uintptr_t>& signatures() {
    static std::map<std::string, std::uintptr_t> table;
    return table;
}
} // namespace stub

inline std::uintptr_t resolveSignature(std::string_view signature, std::string_view /*moduleName*/) {
    const auto it = stub::signatures().find(std::string(signature));
    return it == stub::signatures().end() ? 0 : it->second;
}

} // namespace pl::memory
