#pragma once
// Host-side stand-in for the Preloader SDK header (tests only).
// "Installing" a hook just records the detour so a test can call it in place of the target.
#include <map>

namespace pl::memory {

using FuncPtr = void*;

enum class HookPriority : int { Highest = 0, High = 100, Normal = 200, Low = 300, Lowest = 400 };

namespace stub {
inline std::map<void*, void*>& detours() {
    static std::map<void*, void*> table;
    return table;
}
} // namespace stub

class HookHandle {
public:
    HookHandle() = default;
    HookHandle(FuncPtr target, FuncPtr detour, FuncPtr* original, HookPriority = HookPriority::Normal) {
        if (target == nullptr || detour == nullptr || original == nullptr) return;
        *original = target; // in the test the "original" is the fake engine function itself
        stub::detours()[target] = detour;
        mTarget = target;
        mInstalled = true;
    }
    HookHandle(HookHandle&& o) noexcept : mTarget(o.mTarget), mInstalled(o.mInstalled) {
        o.mTarget = nullptr;
        o.mInstalled = false;
    }
    HookHandle& operator=(HookHandle&& o) noexcept {
        if (this != &o) {
            reset();
            mTarget = o.mTarget;
            mInstalled = o.mInstalled;
            o.mTarget = nullptr;
            o.mInstalled = false;
        }
        return *this;
    }
    HookHandle(const HookHandle&) = delete;
    HookHandle& operator=(const HookHandle&) = delete;
    ~HookHandle() { reset(); }

    [[nodiscard]] bool installed() const { return mInstalled; }
    void reset() {
        if (mInstalled) stub::detours().erase(mTarget);
        mInstalled = false;
        mTarget = nullptr;
    }

private:
    FuncPtr mTarget = nullptr;
    bool mInstalled = false;
};

} // namespace pl::memory
