#include "check.h"
#include "hitreg/Reconciler.h"

using betterhitreg::Reconciler;

int main() {
    Reconciler r;
    Reconciler::Options o;
    o.windowMs = 250;
    o.hurtCooldownMs = 500;
    o.delayThresholdMs = 120;
    r.setOptions(o);

    const Reconciler::ActorKey a = 0x1000, b = 0x2000;

    // First attack is predicted, a second one while waiting is not.
    CHECK(r.beginPrediction(a, 1000));
    CHECK(!r.beginPrediction(a, 1010));

    // Server confirms quickly: matched (caller swallows the duplicate), not late.
    auto c = r.confirm(a, 1060);
    CHECK(c.matched && !c.late && c.latencyMs == 60);

    // Still inside the hurt cooldown: no new prediction. After it: allowed again.
    CHECK(!r.beginPrediction(a, 1400));
    CHECK(r.beginPrediction(a, 1600));

    // Slow confirmation is flagged as late.
    c = r.confirm(a, 1600 + 200);
    CHECK(c.matched && c.late && c.latencyMs == 200);

    // A server flash we did not predict is not matched, and starts the cooldown.
    c = r.confirm(b, 5000);
    CHECK(!c.matched);
    CHECK(!r.beginPrediction(b, 5100));
    CHECK(r.beginPrediction(b, 5600));

    // Unconfirmed prediction becomes a ghost after the window.
    auto ghosts = r.expire(5600 + 100);
    CHECK(ghosts.empty());
    ghosts = r.expire(5600 + 300);
    CHECK(ghosts.size() == 1 && ghosts[0].actor == b);

    // A late server event after the ghost is treated as unmatched.
    c = r.confirm(b, 5600 + 400);
    CHECK(!c.matched);

    const auto& s = r.stats();
    CHECK(s.predicted == 3 && s.confirmed == 2 && s.late == 1 && s.ghosts == 1);

    // Idle targets are forgotten.
    r.expire(100000);
    CHECK(r.beginPrediction(a, 100001));

    std::puts("reconciler_test: OK");
    return 0;
}
