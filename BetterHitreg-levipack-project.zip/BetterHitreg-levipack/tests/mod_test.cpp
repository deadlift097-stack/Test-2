#include "check.h"
#include "mod/BetterHitregMod.h"

#include <string>

int main() {
    auto& mod = betterhitreg::BetterHitregMod::instance();
    auto& lines = mod.getSelf().getLogger().lines;
    auto hasLog = [&](const std::string& needle) {
        for (const auto& l : lines) {
            if (l.find(needle) != std::string::npos) return true;
        }
        return false;
    };

    CHECK(mod.load());
    CHECK(hasLog("Loaded BetterHitreg"));

    // Default config has no signatures: the mod loads, enables, and stays idle.
    CHECK(mod.enable());
    CHECK(hasLog("stays idle"));

    CHECK(mod.disable());
    CHECK(mod.unload());

    std::puts("mod_test: OK");
    return 0;
}
