#include "mod/BetterHitregMod.h"

// Register one long-lived mod object with the Preloader (docs: "Types and Macros").
PL_REGISTER_MOD(betterhitreg::BetterHitregMod, betterhitreg::BetterHitregMod::instance())
