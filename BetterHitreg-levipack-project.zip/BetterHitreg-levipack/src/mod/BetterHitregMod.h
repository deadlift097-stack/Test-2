#pragma once

#include "hooks/BedrockBridge.h"
#include "mod/Config.h"

#include <pl/Config.hpp>
#include <pl/Mod.hpp>

#include <memory>
#include <optional>

namespace betterhitreg {

class BetterHitregMod {
public:
    static BetterHitregMod& instance();

    BetterHitregMod();

    [[nodiscard]] ll::mod::NativeMod& getSelf() const { return mSelf; }

    bool load();
    bool enable();
    bool disable();
    bool unload();

private:
    ll::mod::NativeMod& mSelf;
    std::optional<pl::config::ConfigFile<ModConfig>> mConfig;
    std::unique_ptr<BedrockBridge> mBridge;
};

} // namespace betterhitreg
