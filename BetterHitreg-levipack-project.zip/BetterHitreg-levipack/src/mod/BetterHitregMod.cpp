#include "mod/BetterHitregMod.h"

#include <filesystem>
#include <string_view>
#include <system_error>

namespace betterhitreg {

BetterHitregMod& BetterHitregMod::instance() {
    static BetterHitregMod mod;
    return mod;
}

BetterHitregMod::BetterHitregMod() : mSelf(*ll::mod::NativeMod::current()) {}

bool BetterHitregMod::load() {
    auto& self = getSelf();

    std::error_code ec;
    std::filesystem::create_directories(self.getConfigDir(), ec);

    mConfig.emplace();
    if (!mConfig->load()) {
        self.getLogger().warn("Could not read config.json - using built-in defaults");
    }

    self.getLogger().info("Loaded {}", self.getName());
    return true;
}

bool BetterHitregMod::enable() {
    auto& self = getSelf();
    if (!mConfig) {
        return true;
    }

    const ModConfig& config = mConfig->value();
    if (!config.enabled) {
        self.getLogger().info("Disabled in config.json");
        return true;
    }

    mBridge = std::make_unique<BedrockBridge>([this](std::string_view message) { getSelf().getLogger().info("{}", message); });

    // install() reports every problem itself and leaves the game untouched; the mod stays loaded either way.
    mBridge->install(config);
    return true;
}

bool BetterHitregMod::disable() {
    if (mBridge) {
        mBridge->uninstall();
        mBridge.reset();
    }
    return true;
}

bool BetterHitregMod::unload() {
    mConfig.reset();
    return true;
}

} // namespace betterhitreg
