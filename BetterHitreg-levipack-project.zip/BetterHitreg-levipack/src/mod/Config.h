#pragma once

// Typed config. Keep these as plain aggregates with default member initializers:
// pl::config::ConfigFile<ModConfig> turns them into config/config.json and merges the user's edits.
// config/config.json and config/config.schema.json in this repo mirror these defaults.

#include <pl/Config.hpp>

#include <string>
#include <string_view>

namespace betterhitreg {

struct HitregConfig {
    bool hurtFlash = true;
    int reconcileWindowMs = 250;
    int hurtCooldownMs = 500;
};

struct AlertConfig {
    bool delays = false;
    int delayThresholdMs = 120;
    bool ghosts = false;
};

struct HookConfig {
    std::string moduleName = "libminecraftpe.so";
    std::string attackSignature;
    int attackTargetArg = 1;
    std::string entityEventSignature;
    int hurtEventId = 2;
};

struct ModConfig {
    int version = 1;
    bool enabled = true;
    HitregConfig hitreg;
    AlertConfig alerts;
    HookConfig hooks;
};

} // namespace betterhitreg

// Editor metadata for the launcher's config screen (see the Config API docs, "Schema Metadata").
template <> struct pl::config::Schema<betterhitreg::HitregConfig> {
    static constexpr std::string_view title = "Hit prediction";
    static constexpr std::string_view description = "Show the hurt flash on the target before the server confirms the hit.";

    static constexpr FieldSchema field(std::string_view name) {
        if (name == "hurtFlash") {
            return {.title = "Predict hurt flash", .description = "Flash the target as soon as you attack it."};
        }
        if (name == "reconcileWindowMs") {
            return {.title = "Confirmation window (ms)",
                    .description = "How long to wait for the server's own hurt event before counting a ghost hit.",
                    .minimum = 50,
                    .maximum = 1000};
        }
        if (name == "hurtCooldownMs") {
            return {.title = "Hurt cooldown (ms)",
                    .description = "No new prediction for the same target this soon after its last flash.",
                    .minimum = 0,
                    .maximum = 2000};
        }
        return {};
    }
};

template <> struct pl::config::Schema<betterhitreg::AlertConfig> {
    static constexpr std::string_view title = "Alerts";
    static constexpr std::string_view description = "Diagnostics written to the launcher log.";

    static constexpr FieldSchema field(std::string_view name) {
        if (name == "delays") {
            return {.title = "Log late confirmations", .description = "Log when the server confirms a hit later than the threshold."};
        }
        if (name == "delayThresholdMs") {
            return {.title = "Late threshold (ms)", .description = "Confirmations slower than this count as late.", .minimum = 0, .maximum = 1000};
        }
        if (name == "ghosts") {
            return {.title = "Log ghost hits", .description = "Log predicted hits the server never confirmed."};
        }
        return {};
    }
};

template <> struct pl::config::Schema<betterhitreg::HookConfig> {
    static constexpr std::string_view title = "Game hooks";
    static constexpr std::string_view description =
        "Where to find the game functions. Signatures are specific to one Minecraft version; leave them empty and the mod stays idle.";

    static constexpr FieldSchema field(std::string_view name) {
        if (name == "moduleName") {
            return {.title = "Game library", .description = "Library the signatures are searched in."};
        }
        if (name == "attackSignature") {
            return {.title = "Attack function signature",
                    .description = "Symbol or byte pattern of the function called when the local player attacks an entity."};
        }
        if (name == "attackTargetArg") {
            return {.title = "Target argument index",
                    .description = "Which argument of the attack function is the target entity (0 = this, 1 = first parameter).",
                    .minimum = 0,
                    .maximum = 5};
        }
        if (name == "entityEventSignature") {
            return {.title = "Entity event handler signature",
                    .description = "Symbol or byte pattern of the function that receives entity events (this, event id, data)."};
        }
        if (name == "hurtEventId") {
            return {.title = "Hurt event id",
                    .description = "Event id that plays the hurt animation (2 = HURT_ANIMATION in the Bedrock protocol).",
                    .minimum = 0,
                    .maximum = 255};
        }
        return {};
    }
};

template <> struct pl::config::Schema<betterhitreg::ModConfig> {
    static constexpr std::string_view title = "BetterHitreg";
    static constexpr std::string_view description = "Client-side hit feedback for Minecraft Bedrock.";

    static constexpr FieldSchema field(std::string_view name) {
        if (name == "version") {
            return {.title = "Version", .readOnly = true};
        }
        if (name == "enabled") {
            return {.title = "Enabled", .description = "Turns the whole mod on or off."};
        }
        if (name == "hitreg") {
            return {.title = "Hit prediction"};
        }
        if (name == "alerts") {
            return {.title = "Alerts"};
        }
        if (name == "hooks") {
            return {.title = "Game hooks"};
        }
        return {};
    }
};
