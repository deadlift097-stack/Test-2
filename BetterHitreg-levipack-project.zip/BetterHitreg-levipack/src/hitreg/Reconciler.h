#pragma once

// Pure bookkeeping for "predicted vs. confirmed" hits. No engine or SDK dependencies,
// so it can be unit-tested on a normal computer (see tests/reconciler_test.cpp).

#include <cstdint>
#include <limits>
#include <unordered_map>
#include <vector>

namespace betterhitreg {

using Millis = std::int64_t;

class Reconciler {
public:
    using ActorKey = std::uintptr_t;

    struct Options {
        Millis windowMs = 250;         // how long a prediction waits for the server's matching event
        Millis hurtCooldownMs = 500;   // no new prediction for a target this soon after its last flash
        Millis delayThresholdMs = 120; // confirmations slower than this count as "late"
    };

    struct Stats {
        std::uint64_t predicted = 0;
        std::uint64_t confirmed = 0;
        std::uint64_t late = 0;
        std::uint64_t ghosts = 0;
    };

    struct Confirmation {
        bool matched = false; // true: the server event belongs to a prediction -> swallow it
        bool late = false;
        Millis latencyMs = 0;
    };

    struct Ghost {
        ActorKey actor = 0;
        Millis ageMs = 0;
    };

    void setOptions(const Options& options) { mOptions = options; }
    [[nodiscard]] const Options& options() const { return mOptions; }
    [[nodiscard]] const Stats& stats() const { return mStats; }

    void reset() {
        mActors.clear();
        mStats = {};
    }

    // The local player just attacked `actor`. Returns true when a predicted flash may be shown.
    bool beginPrediction(ActorKey actor, Millis now) {
        State& s = mActors[actor];
        if (s.pendingAt != kNone) {
            return false; // already waiting for the server on this target
        }
        if (s.lastFlashAt != kNone && now - s.lastFlashAt < mOptions.hurtCooldownMs) {
            return false; // target is most likely still in its hurt cooldown
        }
        s.pendingAt = now;
        s.lastFlashAt = now;
        ++mStats.predicted;
        return true;
    }

    // The server told us `actor` was hurt.
    Confirmation confirm(ActorKey actor, Millis now) {
        Confirmation c;
        State& s = mActors[actor];
        if (s.pendingAt != kNone) {
            c.matched = true;
            c.latencyMs = now - s.pendingAt;
            c.late = c.latencyMs > mOptions.delayThresholdMs;
            s.pendingAt = kNone;
            ++mStats.confirmed;
            if (c.late) {
                ++mStats.late;
            }
        } else {
            s.lastFlashAt = now; // a flash we did not predict (someone else's hit, or an expired prediction)
        }
        return c;
    }

    // Drops predictions the server never confirmed ("ghosts") and forgets idle targets.
    std::vector<Ghost> expire(Millis now) {
        std::vector<Ghost> ghosts;
        for (auto it = mActors.begin(); it != mActors.end();) {
            State& s = it->second;
            if (s.pendingAt != kNone && now - s.pendingAt > mOptions.windowMs) {
                ghosts.push_back({it->first, now - s.pendingAt});
                s.pendingAt = kNone;
                ++mStats.ghosts;
            }
            const bool idle = s.pendingAt == kNone;
            const bool cooled = s.lastFlashAt == kNone || now - s.lastFlashAt >= mOptions.hurtCooldownMs;
            if (idle && cooled) {
                it = mActors.erase(it);
            } else {
                ++it;
            }
        }
        return ghosts;
    }

private:
    static constexpr Millis kNone = std::numeric_limits<Millis>::min();

    struct State {
        Millis pendingAt = kNone;
        Millis lastFlashAt = kNone;
    };

    Options mOptions;
    Stats mStats;
    std::unordered_map<ActorKey, State> mActors;
};

} // namespace betterhitreg
