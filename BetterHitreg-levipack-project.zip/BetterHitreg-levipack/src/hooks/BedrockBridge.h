#pragma once

#include "hitreg/Reconciler.h"
#include "mod/Config.h"

#include <pl/memory/Hook.hpp>

#include <array>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <mutex>
#include <string_view>
#include <utility>
#include <vector>

namespace betterhitreg {

using LogFn = std::function<void(std::string_view)>;

// Installs two detours:
//   1. the function the game calls when the local player attacks an entity   -> shows a predicted hurt flash
//   2. the function that receives entity events (this, eventId, data)        -> swallows the server's duplicate flash
//
// Both detours forward the first six integer/pointer registers untouched, so they keep working if the real
// functions take extra parameters. Nothing is hooked until both signatures are configured and resolve.
class BedrockBridge {
public:
    explicit BedrockBridge(LogFn log) : mLog(std::move(log)) {}
    ~BedrockBridge() { uninstall(); }

    BedrockBridge(const BedrockBridge&) = delete;
    BedrockBridge& operator=(const BedrockBridge&) = delete;

    // Returns true when both hooks are live. On any problem it logs why and leaves the game untouched.
    bool install(const ModConfig& config);
    void uninstall();

    [[nodiscard]] bool active() const noexcept { return mActive.load(std::memory_order_acquire); }

private:
    using Reg = std::uintptr_t;
    static constexpr std::size_t kArgCount = 6;
    using Fn6 = Reg (*)(Reg, Reg, Reg, Reg, Reg, Reg);

    static Reg attackDetour(Reg a0, Reg a1, Reg a2, Reg a3, Reg a4, Reg a5);
    static Reg eventDetour(Reg a0, Reg a1, Reg a2, Reg a3, Reg a4, Reg a5);

    void afterAttack(const std::array<Reg, kArgCount>& args);
    bool handleServerHurt(Reg actor);
    void reportGhosts(const std::vector<Reconciler::Ghost>& ghosts) const;

    LogFn mLog;
    ModConfig mConfig;
    Reconciler mReconciler;
    std::mutex mMutex;
    std::atomic<bool> mActive{false};

    Fn6 mOrigAttack = nullptr;
    Fn6 mOrigEvent = nullptr;
    pl::memory::HookHandle mAttackHook;
    pl::memory::HookHandle mEventHook;
};

} // namespace betterhitreg
