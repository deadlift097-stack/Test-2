#include "hooks/BedrockBridge.h"

#include <pl/memory/Signature.hpp>

#include <algorithm>
#include <chrono>
#include <exception>
#include <string>

namespace betterhitreg {

namespace {

std::atomic<BedrockBridge*> gInstance{nullptr};

Millis nowMs() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

// Cheap guard: refuse to hand obviously bogus "entity pointers" back to the game
// (protects against a wrongly configured attackTargetArg).
bool plausiblePointer(std::uintptr_t p) { return p >= 0x10000 && (p & 0x7) == 0; }

} // namespace

bool BedrockBridge::install(const ModConfig& config) {
    uninstall();

    const HookConfig& hooks = config.hooks;
    if (hooks.attackSignature.empty() || hooks.entityEventSignature.empty()) {
        mLog("hooks.attackSignature and hooks.entityEventSignature are empty - hit prediction stays idle (see README)");
        return false;
    }
    if (hooks.attackTargetArg < 0 || hooks.attackTargetArg >= static_cast<int>(kArgCount) || hooks.hurtEventId < 0 ||
        hooks.hurtEventId > 255) {
        mLog("hooks.attackTargetArg must be 0-5 and hooks.hurtEventId must be 0-255 - hit prediction stays idle");
        return false;
    }

    const std::uintptr_t attackAddr = pl::memory::resolveSignature(hooks.attackSignature, hooks.moduleName);
    const std::uintptr_t eventAddr = pl::memory::resolveSignature(hooks.entityEventSignature, hooks.moduleName);
    if (attackAddr == 0 || eventAddr == 0) {
        std::string msg = "Signature not found in " + hooks.moduleName + ":";
        if (attackAddr == 0) {
            msg += " attackSignature";
        }
        if (eventAddr == 0) {
            msg += " entityEventSignature";
        }
        msg += " - hit prediction stays idle (signatures only match one game version)";
        mLog(msg);
        return false;
    }

    mConfig = config;
    mReconciler.reset();
    Reconciler::Options options;
    options.windowMs = std::clamp(config.hitreg.reconcileWindowMs, 50, 1000);
    options.hurtCooldownMs = std::clamp(config.hitreg.hurtCooldownMs, 0, 2000);
    options.delayThresholdMs = std::clamp(config.alerts.delayThresholdMs, 0, 1000);
    mReconciler.setOptions(options);

    gInstance.store(this, std::memory_order_release);

    // Event hook first: a prediction must never exist without the filter that swallows its duplicate.
    mEventHook = pl::memory::HookHandle(reinterpret_cast<void*>(eventAddr), reinterpret_cast<void*>(&BedrockBridge::eventDetour),
                                        reinterpret_cast<void**>(&mOrigEvent), pl::memory::HookPriority::Normal);
    if (!mEventHook.installed()) {
        mLog("Could not hook the entity-event function - hit prediction stays idle");
        uninstall();
        return false;
    }
    mAttackHook = pl::memory::HookHandle(reinterpret_cast<void*>(attackAddr), reinterpret_cast<void*>(&BedrockBridge::attackDetour),
                                         reinterpret_cast<void**>(&mOrigAttack), pl::memory::HookPriority::Normal);
    if (!mAttackHook.installed()) {
        mLog("Could not hook the attack function - hit prediction stays idle");
        uninstall();
        return false;
    }

    mActive.store(true, std::memory_order_release);
    mLog("Hit prediction active");
    return true;
}

void BedrockBridge::uninstall() {
    const bool wasActive = mActive.exchange(false, std::memory_order_acq_rel);
    mAttackHook.reset();
    mEventHook.reset();

    BedrockBridge* expected = this;
    gInstance.compare_exchange_strong(expected, nullptr, std::memory_order_acq_rel);

    mOrigAttack = nullptr;
    mOrigEvent = nullptr;

    if (wasActive) {
        const Reconciler::Stats& s = mReconciler.stats();
        mLog("Session: " + std::to_string(s.predicted) + " predicted, " + std::to_string(s.confirmed) + " confirmed (" +
             std::to_string(s.late) + " late), " + std::to_string(s.ghosts) + " ghost");
    }
}

BedrockBridge::Reg BedrockBridge::attackDetour(Reg a0, Reg a1, Reg a2, Reg a3, Reg a4, Reg a5) {
    BedrockBridge* self = gInstance.load(std::memory_order_acquire);
    if (self == nullptr || self->mOrigAttack == nullptr) {
        return 0;
    }
    // Let the game do its normal attack first; the prediction only adds visuals afterwards.
    const Reg result = self->mOrigAttack(a0, a1, a2, a3, a4, a5);
    if (self->active()) {
        self->afterAttack({a0, a1, a2, a3, a4, a5});
    }
    return result;
}

BedrockBridge::Reg BedrockBridge::eventDetour(Reg a0, Reg a1, Reg a2, Reg a3, Reg a4, Reg a5) {
    BedrockBridge* self = gInstance.load(std::memory_order_acquire);
    if (self == nullptr || self->mOrigEvent == nullptr) {
        return 0;
    }
    // Only the low byte of the event id is meaningful (the argument may be a narrow enum).
    if (self->active() && (a1 & 0xFF) == static_cast<Reg>(self->mConfig.hooks.hurtEventId)) {
        if (self->handleServerHurt(a0)) {
            return 0; // the flash was already predicted: swallow the server's duplicate
        }
    }
    return self->mOrigEvent(a0, a1, a2, a3, a4, a5);
}

void BedrockBridge::afterAttack(const std::array<Reg, kArgCount>& args) {
    try {
        const Reg target = args[static_cast<std::size_t>(mConfig.hooks.attackTargetArg)];
        if (!plausiblePointer(target) || !mConfig.hitreg.hurtFlash) {
            return;
        }

        bool predict = false;
        std::vector<Reconciler::Ghost> ghosts;
        {
            std::lock_guard<std::mutex> lock(mMutex);
            const Millis now = nowMs();
            ghosts = mReconciler.expire(now);
            predict = mReconciler.beginPrediction(target, now);
        }
        reportGhosts(ghosts);

        if (predict && mOrigEvent != nullptr) {
            // Calls the game's own handler (not our detour), so the flash looks exactly like a real one.
            mOrigEvent(target, static_cast<Reg>(mConfig.hooks.hurtEventId), 0, 0, 0, 0);
        }
    } catch (const std::exception&) {
        // Never let an exception cross the hook boundary into game code.
    } catch (...) {
    }
}

bool BedrockBridge::handleServerHurt(Reg actor) {
    try {
        Reconciler::Confirmation confirmation;
        std::vector<Reconciler::Ghost> ghosts;
        {
            std::lock_guard<std::mutex> lock(mMutex);
            const Millis now = nowMs();
            ghosts = mReconciler.expire(now);
            confirmation = mReconciler.confirm(actor, now);
        }
        reportGhosts(ghosts);

        if (confirmation.matched && confirmation.late && mConfig.alerts.delays) {
            mLog("Late hit confirmation: server answered after " + std::to_string(confirmation.latencyMs) + " ms (threshold " +
                 std::to_string(mReconciler.options().delayThresholdMs) + " ms)");
        }
        return confirmation.matched;
    } catch (...) {
        return false;
    }
}

void BedrockBridge::reportGhosts(const std::vector<Reconciler::Ghost>& ghosts) const {
    if (!mConfig.alerts.ghosts) {
        return;
    }
    for (const Reconciler::Ghost& ghost : ghosts) {
        mLog("Ghost hit: predicted flash was not confirmed by the server within " + std::to_string(ghost.ageMs) + " ms");
    }
}

} // namespace betterhitreg
