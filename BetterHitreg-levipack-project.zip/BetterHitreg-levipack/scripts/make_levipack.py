#!/usr/bin/env python3
"""Pack an already-built libBetterHitreg.so into BetterHitreg-<version>-<abi>.levipack.

A .levipack is a zip with one top-level folder (the mod id):

    BetterHitreg/
    +-- manifest.json
    +-- libBetterHitreg.so
    +-- config/
        +-- config.json
        +-- config.schema.json

Usage:
    python3 scripts/make_levipack.py path/to/libBetterHitreg.so [-o out.levipack]
"""

import argparse
import json
import struct
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ELF_MACHINES = {183: "arm64-v8a", 40: "armeabi-v7a", 62: "x86_64", 3: "x86"}


def fail(message: str) -> None:
    sys.exit(f"error: {message}")


def elf_abi(path: Path) -> str:
    with path.open("rb") as f:
        header = f.read(20)
    if len(header) < 20 or header[:4] != b"\x7fELF":
        fail(f"{path.name} is not an ELF shared library")
    (machine,) = struct.unpack_from("<H", header, 18)
    return ELF_MACHINES.get(machine, f"machine-{machine}")


def add_dir(zf: zipfile.ZipFile, name: str) -> None:
    info = zipfile.ZipInfo(name if name.endswith("/") else name + "/")
    info.external_attr = (0o40755 << 16) | 0x10
    zf.writestr(info, b"")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("library", type=Path, help="compiled libBetterHitreg.so")
    parser.add_argument("-o", "--output", type=Path, help="output file (default: ./<id>-<version>-<abi>.levipack)")
    parser.add_argument("--id", default="BetterHitreg", help="package folder = runtime mod id (default: BetterHitreg)")
    args = parser.parse_args()

    manifest_path = ROOT / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("type") != "preload-native":
        fail('manifest.json "type" must be "preload-native"')
    entry = manifest["entry"]

    lib = args.library
    if not lib.is_file():
        fail(f"{lib} does not exist")
    if lib.name != entry:
        fail(f'library must be named "{entry}" (manifest.json "entry"), got "{lib.name}"')
    abi = elf_abi(lib)
    if abi != "arm64-v8a":
        print(f"warning: library is {abi}; the launcher docs recommend arm64-v8a", file=sys.stderr)

    config_dir = ROOT / "config"
    for name in ("config.json", "config.schema.json"):
        path = config_dir / name
        if not path.is_file():
            fail(f"missing {path}")
        json.loads(path.read_text(encoding="utf-8"))  # must at least be valid JSON

    out = args.output or Path.cwd() / f"{args.id}-{manifest['version']}-{abi}.levipack"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        add_dir(zf, args.id)
        add_dir(zf, f"{args.id}/config")
        zf.write(manifest_path, f"{args.id}/manifest.json")
        zf.write(lib, f"{args.id}/{entry}")
        zf.write(config_dir / "config.json", f"{args.id}/config/config.json")
        zf.write(config_dir / "config.schema.json", f"{args.id}/config/config.schema.json")

    print(f"wrote {out}")
    with zipfile.ZipFile(out) as zf:
        for item in zf.infolist():
            print(f"  {item.filename}")


if __name__ == "__main__":
    main()
